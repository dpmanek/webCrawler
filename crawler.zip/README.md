# webCrawler
## 🚀 Steps to Run

1. **Install dependencies**  
   ```sh
   npm i
2. **Run Script**
   ```sh
   npm start
