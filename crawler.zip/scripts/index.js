export * from "./ScrapeBidData.js";
